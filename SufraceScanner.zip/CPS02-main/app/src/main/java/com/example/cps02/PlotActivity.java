package com.example.cps02;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.Comparator;

public class PlotActivity extends AppCompatActivity {

    // creating a variable
    // for our graph view.
    GraphView graphView;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plot);

        ArrayList<Pair<Float,Float>> locations = Location.locations;
        graphView = findViewById(R.id.idGraphView);

        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>();

        locations.sort(new Comparator<Pair<Float, Float>>() {
            @Override
            public int compare(Pair<Float, Float> o1, Pair<Float, Float> o2) {
                if (o1.first > o2.first) {
                    return -1;
                } else if (o1.first.equals(o2.first)) {
                    return 0;
                }
                return 1;
            }
        });

        for(Pair<Float, Float> l: locations){
            Log.d("p",l.first.toString() + " " + l.second.toString());

        }

        for(Pair<Float, Float> l: locations){
            series.appendData(new DataPoint(l.first, l.second), true, locations.size());
        }

        // after adding data to our line graph series.
        // on below line we are setting
        // title for our graph view.

        graphView.setTitle("My Graph View");

        // on below line we are setting
        // text color to our graph view.
        graphView.setTitleColor(R.color.purple_200);

        // on below line we are setting
        // our title text size.
        graphView.setTitleTextSize(18);

        // on below line we are adding
        // data series to our graph view.
//        graphView.addSeries(series);
    }
}
