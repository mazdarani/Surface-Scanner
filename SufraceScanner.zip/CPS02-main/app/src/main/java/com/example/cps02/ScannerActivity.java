package com.example.cps02;

import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.util.Pair;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.Random;

public class ScannerActivity extends AppCompatActivity implements SensorEventListener {

//    private static final float NS2S = ;
    Location location;
    private SensorManager sensorManager;
    private Sensor sensorAcc;
    private Sensor sensorGro;
    private float timestamp_Acc;
    private float timestamp_Gro;
    boolean acc_;
    boolean gro_;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        initSensor();
        setContentView(R.layout.activity_scanner);
        Button buttonStop = findViewById(R.id.button_stop);
        buttonStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(ScannerActivity.this, PlotActivity.class);
                    startActivity(intent);
                }catch(Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    protected void initSensor() {
        location = new Location();
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        sensorGro = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        sensorManager.registerListener(listener_gyro, sensorGro, SensorManager.SENSOR_DELAY_NORMAL);

        sensorAcc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(listener_acc, sensorAcc, SensorManager.SENSOR_DELAY_NORMAL);


    }

    private SensorEventListener listener_gyro = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            location.gyroUpdate(event.values[0], event.values[1], event.values[2]);
            timestamp_Gro = event.timestamp;

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };


    private SensorEventListener listener_acc = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            location.accUpdate(event.values[0], event.values[1], event.values[2]);
            timestamp_Acc = event.timestamp;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

//    @Override
//    public void onSensorChanged(SensorEvent event) {
////        final float dT = (event.timestamp - timestamp);
//////        * NS2S;
////        if (timestamp != 0) {
////            //calculation
////        }
////        timestamp = event.timestamp;
//
//        Log.d("8","************");
//        Log.d("4",String.valueOf(event.values[0]));
//        Log.d("5",String.valueOf(event.);
//    }
//
//    @Override
//    public void onAccuracyChanged(Sensor sensor, int accuracy) {
//
//    }

    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensorAcc, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this,sensorGro, SensorManager.SENSOR_DELAY_NORMAL);
    }
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
