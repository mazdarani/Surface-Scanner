package com.example.cps02;

import android.util.Pair;

import java.util.ArrayList;

public class Location {

    private float x;
    private float z;
    private float ax;
    private float az;
    private float vx;
    private float vz;
    private float t0;
    private float t;
    private float teta;

    static ArrayList<Pair<Float, Float>> locations;

    public Location(){

        this.x = 0;
        this.z = 0;
        this.ax = 0;
        this.az = 0;
        this.vx = 0;
        this.vz = 0;
        this.t = 0;
        this.t0 = System.currentTimeMillis();
        this.teta = 0;
        locations = new ArrayList<>();
    }

    public void gyroUpdate(float x, float y, float z){
        t = System.currentTimeMillis();
        this.x = x;
        this.z = z;

        float deltaTeta = (float) (t-t0)/1000;
        teta += y*deltaTeta;

        update();
    }

    private void update() {
        t = System.currentTimeMillis();
        float deltaT = (float) (t-t0)/1000;
        t0 = t;
        double deltaA = ax * (float) Math.cos(teta) + az * Math.sin(teta);
        double deltaH = az * (float) Math.cos(teta) - ax * Math.sin(teta) - (float)9.66;

        x += vx*deltaT;
        z += vz*deltaT;

        vx += deltaA*deltaT;
        vz += deltaH*deltaT;

        locations.add(new Pair<>(z,x));

    }

    public void accUpdate(float x, float y, float z){
        ax = x;
        az = z;

        this.update();
    }


}
